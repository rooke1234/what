import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResultsymPage } from './resultsym';

@NgModule({
  declarations: [
    ResultsymPage,
  ],
  imports: [
    IonicPageModule.forChild(ResultsymPage),
  ],
})
export class ResultsymPageModule {}
